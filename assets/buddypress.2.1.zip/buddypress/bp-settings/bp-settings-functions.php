<?php

/**
 * BuddyPress Settings Functions
 *
 * @package BuddyPress
 * @subpackage SettingsFunctions
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;
