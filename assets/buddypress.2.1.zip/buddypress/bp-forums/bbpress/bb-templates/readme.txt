This directory is reserved for themes distributed with the bbPress core package.

If you wish to install more themes, you should create a new directory called "my-templates" in the base directory of your bbPress installation and install them there, not here.